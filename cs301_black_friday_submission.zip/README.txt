Running the code:

If you run the code as-is, it will product no output. To see output, do one or more of the following:

Uncomment line 27 to see which columns have missing values
Uncomment line 52 to graph various demographics about the data
Uncomment line 69 to detect outliers in the data and show them
Uncomment line 172 to train the models with 70/30 split and show RMSE
Uncomment line 206 to run scalability analysis and show the resulting graph
Uncomment line 236 to run robustness analysis and show the resulting graph
Uncomment line 273 to run kmeans over all k in range (1, 25) and show the elbow graph. This will take a while as the dataset is large. 
